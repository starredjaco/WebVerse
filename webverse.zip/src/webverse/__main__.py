from __future__ import annotations

from webverse.cli import main

raise SystemExit(main())
